# SHSU Record Book — Global Player Profiles (Fall/Spring/All)

The **existing SQLite database is unchanged**. Importer unchanged. No migration.

## Required edits

1. Back up your current `app.py`, `repository.py` and `templates/player.html`.
2. Merge the changes in `global_player_profiles.patch`, or use the provided updated
   `app.py`, `repository.py`, and `templates/player.html` if you have not customized them.
   **You recently customized player.html, so merge the diff instead of overwriting it.**
3. In `templates/base.html`, make the one-line change:
   `season is defined and season.slug` ->
   `season is defined and season is not none and season.slug`
   (The updated base.html is included as a reference.)
4. Append the contents of `player_filter.css` to your **existing**
   `static/css/style.css`; do not replace your stylesheet.
5. Optional but recommended: change links in templates/team.html and
   templates/season.html from `url_for('player_page', season_slug=season.slug,
   player_slug=...)` to `url_for('player_profile_season',
   view_slug=season.slug, player_slug=...)`. Existing links continue to work
   locally via redirects even without this change; direct paths are better for
   future GitHub Pages static site generation.

## URLs
- `/players/coldest/`: most recent participating season
- `/players/coldest/fall-2026/`: Fall only
- `/players/coldest/spring-2026/`: Spring only, once player belongs to that season
- `/players/coldest/all/`: all seasons, combined
- Existing `/seasons/fall-2026/players/coldest/` redirects to the Fall view.
- Existing `?season=fall-2026` filters redirect to the matching static-friendly path.

## Season visibility
A player can select a season if they're rostered in it OR have recorded
appearances in it. Link Spring 2026 to the existing player_id in
`roster_memberships`; do not create a new Nyx/Coldest/Tango/Noizy player row.

## Calculations
Totals come from the same permanent player ID across all recorded games.
All-time rates and shooting/demo ratios are recalculated from summed raw
game rows; the code never averages seasonal percentages.
On the all-time view, game logs, personal-record winners, and team splits
include a season label.

## Testing performed
- Validated repository queries with Marist's 4 games plus a synthetic one-game
  Spring 2026 fixture in a disposable test copy of the database.
- Confirmed Fall=4, Spring=1, All=5 appearances and combined stats.
- Rendered the three player-view variants with Jinja under StrictUndefined.
- A live Flask browser test was not possible here (Flask unavailable).

## Important for GitHub Pages
Season filters use **paths** rather than a server-side query form. This is
deliberate: `/players/coldest/fall-2026/` and `/players/coldest/all/` can
each be pre-rendered to their own static index.html at deployment time.
The current Flask site works locally; a static site generator is still needed.
